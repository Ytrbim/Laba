﻿using System.Windows;

namespace Scheduler
{
  public partial class App : Application
  {
  }
}
